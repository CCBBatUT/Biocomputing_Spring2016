#!/bin/bash
set -e #terminates the script if any command exits with a non zero status (it failed)
set -u #aborts script if a variables value is unset
set -o pipefail #any non-zero exit status within a pipe will also abort

echo "Okay check out using arguments:"
echo "script name: $0"
echo "first arg: $1"
echo "second arg: $2"

