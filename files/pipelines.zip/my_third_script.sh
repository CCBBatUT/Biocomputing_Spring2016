#!/bin/bash
set -e #terminates the script if any command exits with a non zero status (it failed)
set -u #aborts script if a variables value is unset
set -o pipefail #any non-zero exit status within a pipe will also abort

if [ "$#" -ne 1 ] #is there one argument?
then
	echo "error:  I need just one argument (integer)"
	echo "usage: $0 arg1"
	exit 1
fi

for i in $(seq 1 $1)

do
	echo $i
done
