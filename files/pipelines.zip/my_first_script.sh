#!/bin/bash
set -e #terminates the script if any command exits with a non zero status (it failed)
set -u #aborts script if a variables value is unset
set -o pipefail #any non-zero exit status within a pipe will also abort

echo This is your first script!
echo "First we'll run a simple 'ls' command"
ls
echo "We can also run a 'pwd' command"
pwd

